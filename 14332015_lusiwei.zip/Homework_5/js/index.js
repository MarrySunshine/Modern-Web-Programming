/**
 * Created by lusiwei on 15/11/3.
 */
window.onload = function() {
    screen.init();
    bindClickEvent();
    bindKeyDownEvent();
    showAlert("支持键盘操作");
};
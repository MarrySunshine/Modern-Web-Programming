var server = require("./server/server");
var route = require("./server/route");
server.start();